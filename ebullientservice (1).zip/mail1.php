<?php
   // Only process POST reqeusts.
   if ($_SERVER["REQUEST_METHOD"] == "POST") {

       $email = strip_tags(trim($_POST["email"]));
       $email= str_replace(array("\r","\n"),array(" "," "),$email);

       if ( empty($name) AND empty($message) AND !filter_var($email, FILTER_VALIDATE_EMAIL)) {
           // Set a 400 (bad request) response code and exit.
           http_response_code(400);
           echo "Please complete the form and try again.";
           exit;
       }
       // Set the recipient email address.
       // FIXME: Update this to your desired email address.
       $to = "anu@ebullientservice.com";
       $subject = 'Enquiry Mail';
       $message = '
               <html>
               <body>
               <p>This email contains HTML Tags!</p>
               <table rules="all" style="border-color: #666;" cellpadding="10">
               <tr style="background: #eee;">
               <th>Email</th>
                </tr>
               <tr>
               <td>'.$email.'</td>
               </table>
               </body>
               </html>
               ';
       // Build the email headers.
       $headers = "MIME-Version: 1.0" . "\r\n";
       $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
       $headers .= 'From: <'.$email.'>' . "\r\n";
       // mail($recipient, $message, $email_headers
       // Send the email.
       if (mail($to,$email,$message,$headers)) {
           // Set a 200 (okay) response code.
           http_response_code(200);
           echo "<script> alert('Thank You! Your message has been sent.') </script>" ;
           header('Location: http://outsource.adsvento.com/about-us.html');
       } else {
           // Set a 500 (internal server error) response code.
           http_response_code(500);
           echo "<script> alert('Oops! Something went wrong and we couldn't send your message.') </script>";
       }
   } else {
       // Not a POST request, set a 403 (forbidden) response code.
       http_response_code(403);
       echo "<script> alert('There was a problem with your submission, please try again.') </script>";
   }
?>
